import { Component } from "react";
//look at how mulitply to version an addition to version works
//use className instead of class - class is a reserved word
//use defaultValue instead of Value 
// use camel cased / pascal case for events - onClick example - on - small letter  - Click - C capital letter - it wont work right now as an example of camel case
//inline style must use a config object
//must always use a single root node or React.Fragement or <> - empty tags/alias
/*backgroundColor is again camel cased */
class Herolist extends Component{
    render(){
        return <div className = "box"> 
            <h1>{ this.props.title } | { this.props.version }</h1>
            <h1> { this.props.version * 2 }</h1>
            <h1> { this.props.version + 2 }</h1>
            <ol>{ this.props.list.map((val, idx)=> <li key={idx}>{ val }</li>)}</ol>
        <label htmlFor = "cd"> Username : </label>
        <input id ="cd" type = "checkbox"/>
        <input type="text" defaultValue = "Sravanthi"/>
        {/* <button> onClick="">Click Me </button> */}

        <article style={{ backgroundColor : "silver"}}> 
    
            Welcome to my amazing life
        </article>

        </div>
        
    }
}
export default Herolist;