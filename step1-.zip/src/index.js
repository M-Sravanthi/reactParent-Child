import { Component } from 'react';
import ReactDOM from 'react-dom';
import Herolist from './Components/herolist';
 
 
class App extends Component{
    avengers = ['ironman', 'antman', 'hulk', 'black widow', 'black panther','doctor strange','captain marvel'];
    justiceleague = ['batman', 'superman', 'wonder women', 'flash', 'cyborg', 'aquaman'];
    indicheroes = ['Shaktiman', 'Krish','Junior G', 'Aryaman', 'Phantom' ];
    render(){
        return <>
                <Herolist version = "101" title = "avengers" list={ this.avengers }/>
                <Herolist version = { 102 } title = "Justice league" list={ this.justiceleague }/>
                <Herolist version = "103" title = "Indic Heroes" list={ this.indicheroes }/>
               </>
    }
}
 
ReactDOM.render(<App/>, document.getElementById("root"));